#!/bin/bash
echo "🔧 Instalacja Czuła Sieć – AI Orchestrator + Security START"

cd "$(dirname "$0")" || exit 1

echo "📝 Tworzenie pliku .env..."
cat <<EOF > .env
PORT=3000
ADMIN_PANEL_URL=http://localhost:3000/admin

SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

JWT_SECRET=supersekretnyklucz123
JWT_EXPIRES_IN=2h

RECAPTCHA_SECRET_KEY=your-recaptcha-key
TWO_FA_SECRET=your-2fa-secret

AI_MODE=enabled
PROMPT_STORAGE_PATH=./prompts/
LOGS_PATH=./logs/

SUPPORT_EMAIL=kontakt@czulasiec.pl
NODE_ENV=production
EOF

chmod 600 .env

echo "📦 Instalacja zależności (npm)..."
if [ -f package.json ]; then
  npm install
fi

mkdir -p prompts logs

echo "🚀 Uruchamianie projektu..."
nohup npm run dev > logs/output.log 2>&1 &

echo "✅ Serwis Czuła Sieć uruchomiony na porcie 3000"
