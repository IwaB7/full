#!/bin/bash
echo 'Backup database...'